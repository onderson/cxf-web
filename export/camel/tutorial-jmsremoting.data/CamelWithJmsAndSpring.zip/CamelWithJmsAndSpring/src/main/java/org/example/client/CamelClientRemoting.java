/**
 *
 */
package org.example.client;

import org.example.server.Multiplier;
import org.junit.Assert;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Requires that the JMS broker is running, as well as CamelServer
 * @author martin.gilday
 *
 */
public class CamelClientRemoting {

	public static void main(final String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("camel-client-remoting.xml");
		Multiplier multiplier = (Multiplier) context.getBean("multiplierProxy");

		int response = multiplier.multiply(22);

		Assert.assertEquals(66, response);
		System.out.println(response);
	}

}
