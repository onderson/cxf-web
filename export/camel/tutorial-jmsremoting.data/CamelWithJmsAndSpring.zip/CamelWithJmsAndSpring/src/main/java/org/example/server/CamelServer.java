/**
 *
 */
package org.example.server;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author martin.gilday
 *
 */
public class CamelServer {

	/**
	 * @param args
	 */
	public static void main(final String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("META-INF/spring/camel-server.xml");
	}

}
