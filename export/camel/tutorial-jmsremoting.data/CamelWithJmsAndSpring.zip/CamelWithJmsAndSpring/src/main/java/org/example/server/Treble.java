/**
 *
 */
package org.example.server;

import org.springframework.stereotype.Service;

/**
 * @author martin.gilday
 *
 */
@Service(value="multiplier")
public class Treble implements Multiplier {

	/* (non-Javadoc)
	 * @see org.example.server.Multiplier#multiply(int)
	 */
	public int multiply(final int originalNumber) {
		return originalNumber * 3;
	}

}
