/**
 *
 */
package org.example.server;

import org.apache.camel.builder.RouteBuilder;

/**
 * @author martin.gilday
 *
 */
public class ServerRoutes extends RouteBuilder {

	/* (non-Javadoc)
	 * @see org.apache.camel.builder.RouteBuilder#configure()
	 */
	@Override
	public void configure() throws Exception {
		from("jms:queue:numbers").beanRef("multiplier", "multiply");
	}

}
