/**
 *
 */
package org.example.client;

import org.apache.camel.CamelTemplate;
import org.apache.camel.ExchangePattern;
import org.apache.camel.component.jms.JmsExchange;
import org.junit.Assert;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Requires that the JMS broker is running, as well as CamelServer
 * @author martin.gilday
 *
 */
public class CamelClient {

	public static void main(final String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("camel-client.xml");
		CamelTemplate<JmsExchange> camelTemplate = (CamelTemplate) context.getBean("camelTemplate");

		int response = (Integer)camelTemplate.sendBody("jms:queue:numbers",
				ExchangePattern.InOut,
            	22
		);

		Assert.assertEquals(66, response);
		System.out.println(response);

	}

}
