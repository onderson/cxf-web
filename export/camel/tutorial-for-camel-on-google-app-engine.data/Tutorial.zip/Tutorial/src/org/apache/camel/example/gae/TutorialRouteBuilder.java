package org.apache.camel.example.gae;

import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.gae.mail.GMailBinding;

public class TutorialRouteBuilder extends RouteBuilder {

    @Override
    public void configure() throws Exception {
        from("ghttp:///weather")
            .to("gtask://default")
            .setHeader(Exchange.CONTENT_TYPE, constant("text/plain"))
            .transform(constant("Weather report will be sent to ").append(header("mailto")));
      
        from("gtask://default")
            .setHeader(Exchange.HTTP_QUERY, constant("weather=").append(header("city")))
            .to("ghttp://www.google.com/ig/api")
            .process(new WeatherProcessor())        
            .setHeader(GMailBinding.GMAIL_SUBJECT, constant("Weather report"))
            .setHeader(GMailBinding.GMAIL_TO, header("mailto"))
            .to("gmail://krasserm@googlemail.com");
    }

}
