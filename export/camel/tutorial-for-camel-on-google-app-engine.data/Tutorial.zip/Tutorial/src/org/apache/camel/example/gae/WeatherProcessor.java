package org.apache.camel.example.gae;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.w3c.dom.Document;

public class WeatherProcessor implements Processor {

    @Override
    public void process(Exchange exchange) throws Exception {
        // convert XML body to DOM tree
        Document doc = exchange.getIn().getBody(Document.class);

        XPathFactory xpfactory = XPathFactory.newInstance();
        XPath xpath = xpfactory.newXPath();

        // Extract result values via XPath
        String city = xpath.evaluate("//forecast_information/city/@data", doc);
        String cond = xpath.evaluate("//current_conditions/condition/@data", doc);
        String temp = xpath.evaluate("//current_conditions/temp_c/@data", doc);

        String msg = null;
        if (city != null && city.length() > 0) {
            msg = new StringBuffer()
                .append("\n").append("Weather report for:  ").append(city)
                .append("\n").append("Current condition:   ").append(cond)
                .append("\n").append("Current temperature: ").append(temp).append(" (Celsius)").toString();
        } else {
            // create an error message
            msg = "Error getting weather report for " + exchange.getIn().getHeader("city", String.class);
        }
        exchange.getIn().setBody(msg);
    }

}
