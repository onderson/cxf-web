To facilitate OSGi bundle manifest generation, the archetype uses Felix maven plugin.
The manifest will be generated when building the project. To trigger this, run:

mvn package

Please see http://felix.apache.org/site/maven-bundle-plugin-bnd.html for more information.