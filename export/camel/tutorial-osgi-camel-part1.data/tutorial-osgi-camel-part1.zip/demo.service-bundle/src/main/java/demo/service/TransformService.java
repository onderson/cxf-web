package demo.service;

public interface TransformService {
	
	public Object transform(Object obj);

}
